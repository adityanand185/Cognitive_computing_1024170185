# Cognitive Computing Lab Assignment 9 — Two Python Projects

This package contains two independent, runnable computer-vision projects:

1. **Medicine Bottle Label Reader** — reads text from a medicine/package label using OCR and extracts likely fields such as medicine name, strength, expiry date, batch number and MRP.
2. **Emotion-Aware Cognitive Assistant** — detects a face in a camera image and predicts one of seven facial-expression classes using a CNN trained on FER-2013.

> **Important limitations**
> - The medicine reader is an OCR/demo aid, not a medical device. OCR can misread text. Always verify the original package and consult a pharmacist/doctor for medicine, dosage, expiry or safety decisions. It does not recommend medicines or determine a safe dose.
> - Facial-expression predictions are approximate visual classifications, not reliable measurements of a person's inner emotional state. Do not use them for hiring, grading, diagnosis, surveillance or other consequential decisions. The app processes one image at a time and does not save it by default.

## Folder structure

```text
cognitive_computing_lab9/
├── README.md
├── medicine_label_reader/
│   ├── app.py
│   ├── ocr_engine.py
│   └── requirements.txt
└── emotion_aware_assistant/
    ├── app.py
    ├── train.py
    ├── model_utils.py
    ├── requirements.txt
    └── requirements-macos-apple-silicon.txt
```

## Recommended environment

Use **Python 3.10 or 3.11**. Create a separate virtual environment for each project because OCR and TensorFlow dependencies are independent.

---

# Project 1 — Medicine Bottle Label Reader

## What it does

- Accepts a JPG, JPEG or PNG label photo.
- Lets you optionally use your computer/phone camera.
- Improves contrast and enlarges the image before OCR.
- Uses Tesseract OCR to extract printed text.
- Uses pattern matching to identify likely expiry date, batch/lot number, MRP and strength.
- Shows the raw OCR text so you can verify every extracted field.

### A. Install Tesseract

**macOS (Homebrew):**
```bash
brew install tesseract
```

**Ubuntu/Debian:**
```bash
sudo apt update
sudo apt install tesseract-ocr
```

**Windows:**
1. Install the Tesseract OCR application from the UB-Mannheim Windows builds:
   https://github.com/UB-Mannheim/tesseract/wiki
2. During installation, note the installation path (commonly `C:\Program Files\Tesseract-OCR\tesseract.exe`).
3. If Tesseract is not on PATH, set its path in the app's sidebar.

### B. Set up and run

```bash
cd medicine_label_reader
python3 -m venv .venv
source .venv/bin/activate          # macOS/Linux
# .venv\Scripts\activate           # Windows PowerShell
python -m pip install --upgrade pip
pip install -r requirements.txt
streamlit run app.py
```

Open the local URL printed in the terminal (usually http://localhost:8501).

### C. Try it

- Photograph a medicine carton/bottle label in bright, even light.
- Keep the label flat, focused and readable; avoid glare and steep angles.
- Upload the photo or capture it with the camera.
- Review the **raw OCR output**. Correct any OCR mistakes manually before relying on the extracted fields.

### Dataset

For this OCR project, a custom dataset is not required to run the demo: Tesseract is a pre-trained OCR engine. For an academic evaluation, build a small labelled test set of medicine-label photos that you are permitted to use. Keep a CSV with columns `image,ground_truth_text`; compare OCR output against the ground truth and report character/word error rates. Do not upload personal prescription labels without permission.

Possible public dataset search:
- Kaggle medicine packaging / pharmaceutical label datasets: https://www.kaggle.com/datasets?search=medicine%20label
- Open Images (general packaging/object imagery): https://storage.googleapis.com/openimages/web/index.html

Dataset licenses and image permissions vary; check them before use. The app does not automatically download third-party datasets.

---

# Project 2 — Emotion-Aware Cognitive Assistant

## What it does

- Captures one still image from a webcam or accepts an uploaded image.
- Detects the largest face using OpenCV's built-in Haar cascade.
- Converts the face crop to 48×48 grayscale.
- Predicts one of seven FER-2013 expression labels using a small CNN.
- Displays class scores and a neutral, non-diagnostic assistant message.

### A. Install dependencies

**macOS Apple Silicon (M1/M2/M3/M4/M5):**
```bash
cd emotion_aware_assistant
python3 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements-macos-apple-silicon.txt
```

**Windows / Linux:**
```bash
cd emotion_aware_assistant
python -m venv .venv
# activate the environment as shown above
python -m pip install --upgrade pip
pip install -r requirements.txt
```

If TensorFlow installation fails, use Python 3.10 or 3.11 and install the TensorFlow version supported by your operating system. On Apple Silicon, the macOS requirements file uses `tensorflow` and does not require a separate GPU plugin.

### B. Download FER-2013 dataset

The training script supports either:
- A folder dataset with `train/<class_name>/...` and `test/<class_name>/...`, or
- The original FER-2013 CSV with `emotion` and `pixels` columns.

One convenient public Kaggle dataset is:
https://www.kaggle.com/datasets/msambare/fer2013

Download it manually from Kaggle (sign-in may be required), unzip it, and locate the `train` and `test` folders. Then train:

```bash
python train.py --data_dir "/absolute/path/to/fer2013"
```

For the original CSV format:
```bash
python train.py --csv_path "/absolute/path/to/fer2013.csv" --epochs 25
```

The script saves:
- `emotion_model.keras`
- `class_names.json`

in the project folder.

**Training note:** FER-2013 is a relatively small, noisy research dataset. Training time varies by computer. Start with 10 epochs for a quick lab demo; increase to 25–40 for a more complete experiment. You can also use a pre-trained model only if you have permission to use and redistribute it; this project trains its own model.

### C. Run the assistant

After training completes:
```bash
streamlit run app.py
```

Upload a face photo or take a webcam snapshot. The app needs a trained `emotion_model.keras` and `class_names.json` in the project folder.

### D. Dataset labels

FER-2013 typically uses these seven classes:
`angry, disgust, fear, happy, sad, surprise, neutral`.

The code reads folder class names and maps them to the standard order when possible. For CSV data, it uses the standard FER-2013 integer mapping.

---

# Suggested lab demonstration sequence

1. Explain the problem statement and objective.
2. Show the architecture and libraries used.
3. Run the medicine reader with a clear label photo; explain image preprocessing, OCR and regex extraction.
4. Run the emotion assistant with a face image; explain face detection, grayscale conversion, resizing and CNN classification.
5. Discuss limitations, possible improvements and ethical considerations.
6. Show screenshots and record the software versions used in your lab report.

## Troubleshooting

- **`tesseract is not installed`**: install Tesseract separately; `pip install pytesseract` installs only the Python wrapper.
- **OCR gives poor output**: use a sharper, well-lit image, crop tightly around the label and avoid reflections.
- **No face detected**: face the camera, improve lighting and move closer; try a front-facing photo.
- **Emotion model missing**: download FER-2013 and run `python train.py` before starting the emotion app.
- **TensorFlow install errors**: use Python 3.10/3.11 in a fresh environment and follow the platform-specific TensorFlow installation instructions.
