import streamlit as st
from PIL import Image

from ocr_engine import configure_tesseract, preprocess_image, run_ocr, extract_fields

st.set_page_config(page_title="Medicine Label Reader", page_icon="💊", layout="wide")
st.title("💊 Medicine Bottle Label Reader")
st.caption("Vision-based cognitive system • OCR + image preprocessing + text-field extraction")

with st.sidebar:
    st.header("Settings")
    tesseract_path = st.text_input(
        "Tesseract executable path (optional)",
        placeholder=r"C:\Program Files\Tesseract-OCR\tesseract.exe",
        help="Usually leave blank on macOS/Linux if Tesseract is on PATH."
    )
    st.info("Tesseract OCR must be installed separately from the Python packages.")

st.warning(
    "Educational demonstration only. OCR may misread medicine labels. "
    "Always verify the original packaging; do not use this app to decide dosage or treatment."
)

uploaded = st.file_uploader("Upload a medicine bottle/carton label", type=["png", "jpg", "jpeg"])
camera = st.camera_input("Or take a label photo")

source = camera if camera is not None else uploaded

if source is None:
    st.markdown("### How to get a good scan")
    st.write("Use bright, even light; keep the label flat and in focus; avoid glare; include the printed text.")
else:
    image = Image.open(source).convert("RGB")
    left, right = st.columns(2)
    with left:
        st.subheader("Input image")
        st.image(image, use_container_width=True)
    error = configure_tesseract(tesseract_path)
    if error:
        st.error(error)
        st.stop()

    processed = preprocess_image(image)
    with right:
        st.subheader("Preprocessed image")
        st.image(processed, clamp=True, channels="GRAY", use_container_width=True)

    with st.spinner("Reading label text..."):
        raw_text = run_ocr(processed)
        fields = extract_fields(raw_text)

    st.subheader("Extracted information — verify manually")
    cols = st.columns(2)
    for i, (key, value) in enumerate(fields.items()):
        cols[i % 2].metric(key, value)

    st.subheader("Raw OCR text")
    if raw_text:
        st.text_area("Text recognized by OCR", raw_text, height=220)
    else:
        st.info("No text was detected. Try a sharper, brighter or closer image.")

    st.caption("The extracted fields are heuristic guesses, not verified medicine data.")
