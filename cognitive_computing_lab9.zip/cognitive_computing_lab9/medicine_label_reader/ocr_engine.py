import re
import shutil
from datetime import datetime
from typing import Dict, Optional, Tuple

import cv2
import numpy as np
import pytesseract
from PIL import Image


def configure_tesseract(custom_path: str = "") -> Optional[str]:
    """Configure Tesseract executable. Return an error message, or None."""
    if custom_path.strip():
        pytesseract.pytesseract.tesseract_cmd = custom_path.strip()
    elif not shutil.which("tesseract"):
        return (
            "Tesseract executable was not found. Install it separately "
            "and enter its full path in the sidebar."
        )
    try:
        pytesseract.get_tesseract_version()
    except Exception as exc:
        return f"Could not start Tesseract: {exc}"
    return None


def preprocess_image(pil_image: Image.Image) -> np.ndarray:
    """Upscale and enhance a label photo for OCR."""
    rgb = np.array(pil_image.convert("RGB"))
    bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    h, w = bgr.shape[:2]
    scale = 2 if max(h, w) < 1800 else 1
    if scale > 1:
        bgr = cv2.resize(bgr, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)

    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    gray = cv2.bilateralFilter(gray, 9, 75, 75)
    # Adaptive threshold helps with uneven lighting and curved packaging.
    enhanced = cv2.adaptiveThreshold(
        gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
        cv2.THRESH_BINARY, 31, 11
    )
    return enhanced


def run_ocr(image: np.ndarray) -> str:
    # PSM 6 assumes a block of text; raw output is always shown for verification.
    config = "--oem 3 --psm 6"
    return pytesseract.image_to_string(image, config=config).strip()


def _first_match(patterns, text: str) -> str:
    for pattern in patterns:
        match = re.search(pattern, text, flags=re.IGNORECASE | re.MULTILINE)
        if match:
            return match.group(1).strip(" :.-")
    return "Not detected"


def extract_fields(text: str) -> Dict[str, str]:
    """Heuristic field extraction; OCR output must be checked by a human."""
    expiry = _first_match([
        r"(?:EXP(?:IRY)?\.?\s*DATE|EXP\.?)\s*[:\-]?\s*([0-3]?\d[\/\-.][01]?\d[\/\-.](?:20)?\d{2})",
        r"(?:EXP(?:IRY)?\.?\s*DATE|EXP\.?)\s*[:\-]?\s*((?:0?[1-9]|1[0-2])[\/\-.](?:20)?\d{2})",
        r"(?:USE\s*BEFORE|BEST\s*BEFORE)\s*[:\-]?\s*([A-Z]{3,9}\s*[- ]?\d{2,4})",
    ], text)

    batch = _first_match([
        r"(?:BATCH|BATCH\s*NO\.?|B\.?\s*NO\.?|LOT\s*NO\.?)\s*[:#\-]?\s*([A-Z0-9][A-Z0-9\/\-]{2,})"
    ], text)

    mrp = _first_match([
        r"(?:MRP|MAX\.?\s*RETAIL\s*PRICE)\s*[:\-]?\s*(?:RS\.?|₹)?\s*([0-9]+(?:[.,][0-9]{1,2})?)"
    ], text)

    strength = _first_match([
        r"\b(\d+(?:\.\d+)?\s*(?:mg|mcg|µg|g|ml|iu|%))\b"
    ], text)

    # Best-effort product name: first non-empty line that is not an obvious field label.
    ignored = re.compile(
        r"\b(exp|expiry|mfg|manufactur|batch|lot|mrp|price|dosage|composition|"
        r"tablet|capsule|syrup|use before|best before)\b", re.I
    )
    candidate = "Not detected"
    for line in text.splitlines():
        clean = re.sub(r"[^A-Za-z0-9 &()+./-]", "", line).strip()
        if len(clean) >= 4 and not ignored.search(clean) and sum(c.isalpha() for c in clean) >= 3:
            candidate = clean[:80]
            break

    return {
        "Likely medicine / product name": candidate,
        "Strength": strength,
        "Expiry date": expiry,
        "Batch / lot number": batch,
        "MRP (price)": mrp,
    }
