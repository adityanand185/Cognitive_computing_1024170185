import json
from pathlib import Path

import cv2
import numpy as np
import tensorflow as tf

IMAGE_SIZE = 48
STANDARD_CLASSES = ["angry", "disgust", "fear", "happy", "sad", "surprise", "neutral"]

CASCADE_PATH = cv2.data.haarcascades + "haarcascade_frontalface_default.xml"


def build_model(num_classes=7):
    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=(IMAGE_SIZE, IMAGE_SIZE, 1)),
        tf.keras.layers.Conv2D(32, 3, padding="same", activation="relu"),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.MaxPooling2D(),
        tf.keras.layers.Dropout(0.20),

        tf.keras.layers.Conv2D(64, 3, padding="same", activation="relu"),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.MaxPooling2D(),
        tf.keras.layers.Dropout(0.25),

        tf.keras.layers.Conv2D(128, 3, padding="same", activation="relu"),
        tf.keras.layers.BatchNormalization(),
        tf.keras.layers.MaxPooling2D(),
        tf.keras.layers.Dropout(0.30),

        tf.keras.layers.Flatten(),
        tf.keras.layers.Dense(128, activation="relu"),
        tf.keras.layers.Dropout(0.40),
        tf.keras.layers.Dense(num_classes, activation="softmax"),
    ])
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=1e-3),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


def detect_largest_face(pil_image):
    rgb = np.array(pil_image.convert("RGB"))
    gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
    cascade = cv2.CascadeClassifier(CASCADE_PATH)
    faces = cascade.detectMultiScale(
        gray, scaleFactor=1.1, minNeighbors=5, minSize=(40, 40)
    )
    if len(faces) == 0:
        return None, rgb, None
    x, y, w, h = max(faces, key=lambda box: box[2] * box[3])
    # Add a modest margin, clipped to image bounds.
    margin = int(0.12 * max(w, h))
    x0, y0 = max(0, x - margin), max(0, y - margin)
    x1, y1 = min(gray.shape[1], x + w + margin), min(gray.shape[0], y + h + margin)
    crop = gray[y0:y1, x0:x1]
    crop = cv2.resize(crop, (IMAGE_SIZE, IMAGE_SIZE), interpolation=cv2.INTER_AREA)
    crop = crop.astype("float32") / 255.0
    crop = np.expand_dims(crop, axis=(0, -1))
    annotated = rgb.copy()
    cv2.rectangle(annotated, (x, y), (x + w, y + h), (0, 220, 0), 3)
    return crop, annotated, (x, y, w, h)


def load_class_names(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)
