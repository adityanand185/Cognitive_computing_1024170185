import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd
import tensorflow as tf
from PIL import Image

from model_utils import build_model, IMAGE_SIZE, STANDARD_CLASSES


def load_folder_dataset(data_dir):
    root = Path(data_dir)
    train_dir = root / "train"
    test_dir = root / "test"
    if not train_dir.exists() or not test_dir.exists():
        raise FileNotFoundError(
            "Expected data_dir/train/<class>/images and data_dir/test/<class>/images."
        )

    class_dirs = [p for p in train_dir.iterdir() if p.is_dir()]
    # Standardize order when the folder names match FER classes.
    names_lower = {p.name.lower(): p for p in class_dirs}
    if all(name in names_lower for name in STANDARD_CLASSES):
        class_names = STANDARD_CLASSES
    else:
        class_names = sorted(p.name for p in class_dirs)

    def load_split(split_dir):
        xs, ys = [], []
        for label, class_name in enumerate(class_names):
            folder = split_dir / class_name
            if not folder.exists():
                continue
            for path in folder.rglob("*"):
                if path.suffix.lower() not in {".jpg", ".jpeg", ".png", ".bmp"}:
                    continue
                try:
                    img = Image.open(path).convert("L").resize((IMAGE_SIZE, IMAGE_SIZE))
                    xs.append(np.asarray(img, dtype=np.uint8))
                    ys.append(label)
                except Exception:
                    continue
        if not xs:
            raise ValueError(f"No images found in {split_dir}")
        return np.array(xs), np.array(ys, dtype=np.int64)

    x_train, y_train = load_split(train_dir)
    x_test, y_test = load_split(test_dir)
    return x_train, y_train, x_test, y_test, class_names


def load_csv_dataset(csv_path):
    df = pd.read_csv(csv_path)
    if not {"emotion", "pixels"}.issubset(df.columns):
        raise ValueError("CSV must contain 'emotion' and 'pixels' columns.")
    pixels = np.stack([
        np.fromstring(value, sep=" ", dtype=np.uint8).reshape(48, 48)
        for value in df["pixels"].astype(str)
    ])
    labels = df["emotion"].astype(int).to_numpy()
    # Original FER-2013 integer label mapping.
    class_names = STANDARD_CLASSES
    if labels.min() < 0 or labels.max() >= len(class_names):
        raise ValueError("Unexpected emotion labels in CSV.")
    if "Usage" in df.columns:
        usage = df["Usage"].astype(str).str.lower()
        train_mask = usage.str.contains("training").to_numpy()
        test_mask = usage.str.contains("publictest|privatetest|testing", regex=True).to_numpy()
        if not test_mask.any():
            # Keep a reproducible holdout if CSV has no recognizable test split.
            rng = np.random.default_rng(42)
            indices = rng.permutation(len(df))
            split = int(0.8 * len(indices))
            train_mask = np.zeros(len(df), dtype=bool)
            test_mask = np.zeros(len(df), dtype=bool)
            train_mask[indices[:split]] = True
            test_mask[indices[split:]] = True
    else:
        rng = np.random.default_rng(42)
        indices = rng.permutation(len(df))
        split = int(0.8 * len(indices))
        train_mask = np.zeros(len(df), dtype=bool)
        test_mask = np.zeros(len(df), dtype=bool)
        train_mask[indices[:split]] = True
        test_mask[indices[split:]] = True

    return (
        pixels[train_mask], labels[train_mask],
        pixels[test_mask], labels[test_mask], class_names
    )


def main():
    parser = argparse.ArgumentParser(description="Train a FER-2013 facial-expression CNN.")
    parser.add_argument("--data_dir", type=str, help="Dataset folder containing train/ and test/.")
    parser.add_argument("--csv_path", type=str, help="Original FER-2013 CSV file.")
    parser.add_argument("--epochs", type=int, default=15)
    parser.add_argument("--batch_size", type=int, default=64)
    args = parser.parse_args()

    if bool(args.data_dir) == bool(args.csv_path):
        parser.error("Provide exactly one of --data_dir or --csv_path.")

    if args.csv_path:
        x_train, y_train, x_test, y_test, class_names = load_csv_dataset(args.csv_path)
    else:
        x_train, y_train, x_test, y_test, class_names = load_folder_dataset(args.data_dir)

    x_train = x_train.astype("float32")[..., None] / 255.0
    x_test = x_test.astype("float32")[..., None] / 255.0

    print(f"Training images: {len(x_train):,}; test images: {len(x_test):,}")
    print("Classes:", class_names)

    model = build_model(num_classes=len(class_names))
    callbacks = [
        tf.keras.callbacks.EarlyStopping(
            monitor="val_loss", patience=5, restore_best_weights=True
        ),
        tf.keras.callbacks.ReduceLROnPlateau(
            monitor="val_loss", factor=0.5, patience=2, min_lr=1e-5
        ),
    ]

    model.fit(
        x_train, y_train,
        validation_split=0.1,
        epochs=args.epochs,
        batch_size=args.batch_size,
        callbacks=callbacks,
        verbose=1,
    )
    loss, accuracy = model.evaluate(x_test, y_test, verbose=0)
    print(f"Test loss: {loss:.4f} | Test accuracy: {accuracy:.4f}")

    model.save("emotion_model.keras")
    with open("class_names.json", "w", encoding="utf-8") as f:
        json.dump(class_names, f, indent=2)
    print("Saved emotion_model.keras and class_names.json")


if __name__ == "__main__":
    main()
