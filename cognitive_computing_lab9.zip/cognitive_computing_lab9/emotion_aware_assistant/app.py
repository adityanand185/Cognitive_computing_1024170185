from pathlib import Path

import streamlit as st
import numpy as np
import tensorflow as tf
from PIL import Image

from model_utils import detect_largest_face, STANDARD_CLASSES

st.set_page_config(page_title="Emotion-Aware Assistant", page_icon="🙂", layout="wide")
st.title("🙂 Emotion-Aware Cognitive Assistant")
st.caption("Facial-expression classification • OpenCV face detection + CNN")

st.warning(
    "This is an educational demo. Facial expressions do not reliably reveal a person's "
    "inner emotional state. Predictions may be wrong and should not be used for diagnosis "
    "or decisions about people. Images are processed for this session and are not saved by this app."
)

MODEL_PATH = Path(__file__).with_name("emotion_model.keras")
CLASSES_PATH = Path(__file__).with_name("class_names.json")

@st.cache_resource
def load_model():
    return tf.keras.models.load_model(MODEL_PATH)

if not MODEL_PATH.exists() or not CLASSES_PATH.exists():
    st.error("Trained model files are missing. Follow README.md and run train.py first.")
    st.code("python train.py --data_dir \"/path/to/fer2013\" --epochs 15")
    st.stop()

import json
with open(CLASSES_PATH, "r", encoding="utf-8") as f:
    class_names = json.load(f)

try:
    model = load_model()
except Exception as exc:
    st.error(f"Could not load model: {exc}")
    st.stop()

uploaded = st.file_uploader("Upload a face photo", type=["png", "jpg", "jpeg"])
camera = st.camera_input("Or take a webcam snapshot")
source = camera if camera is not None else uploaded

if source is None:
    st.info("Use a clear, front-facing image with one visible face and even lighting.")
else:
    image = Image.open(source).convert("RGB")
    crop, annotated, _ = detect_largest_face(image)
    left, right = st.columns(2)
    with left:
        st.subheader("Input image")
        st.image(image, use_container_width=True)
    if crop is None:
        st.warning("No face detected. Try a clearer, front-facing image with better lighting.")
    else:
        with right:
            st.subheader("Detected face")
            st.image(annotated, use_container_width=True)
        probabilities = model.predict(crop, verbose=0)[0]
        best_index = int(np.argmax(probabilities))
        best_label = class_names[best_index]
        messages = {
            "happy": "The visible expression is classified as happy. Keep doing what feels positive.",
            "sad": "The visible expression is classified as sad. If you are having a hard time, consider taking a break or talking with someone you trust.",
            "angry": "The visible expression is classified as angry. A pause and a few slow breaths may help if that feels useful.",
            "fear": "The visible expression is classified as fearful. Take your time and focus on what would help you feel comfortable.",
            "surprise": "The visible expression is classified as surprised. Something may have caught your attention!",
            "disgust": "The visible expression is classified as disgusted. Check whether anything around you is uncomfortable.",
            "neutral": "The visible expression is classified as neutral. No strong expression was detected.",
        }
        st.subheader("Model prediction")
        st.metric("Most likely expression", best_label.title(), f"{probabilities[best_index] * 100:.1f}% model score")
        st.write(messages.get(best_label.lower(), "Expression prediction completed."))
        st.caption("The percentage is the model's output score, not a calibrated probability of someone's true emotion.")

        st.subheader("Scores by class")
        score_data = {
            name.title(): float(probabilities[i])
            for i, name in enumerate(class_names)
        }
        st.bar_chart(score_data)
